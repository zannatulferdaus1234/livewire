<!DOCTYPE html>
<html >
    <head>

        <title>Laravel</title>
        @livewireStyles


    </head>
    <body class="">
         @livewire('hello-world',['names' => 'chika'])  {{--livewire component called hello-world @LIVEWIRE->livewire directive live @include--}}

        @livewireScripts
    </body>
</html>
