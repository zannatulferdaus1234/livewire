@extends('layout.app')


@section('content')
     @livewire('auth.register')

@endsection
