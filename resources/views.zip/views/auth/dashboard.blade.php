@extends('layout.app')


@section('content')
     @livewire('auth.dashboard')

@endsection
