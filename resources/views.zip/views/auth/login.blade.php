@extends('layout.app')


@section('content')
     @livewire('auth.login')

@endsection
