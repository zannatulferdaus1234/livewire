<div>
    <h1>{{ $title }} </h1>
    <!-- When there is no desire, all things are at peace. - Laozi -->
</div>
