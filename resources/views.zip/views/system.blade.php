<!DOCTYPE html>
<html >
    <head>

        <title>Livewire</title>
        @livewireStyles


    </head>
    <body class="">

         @livewire('school')


        @livewireScripts
    </body>
</html>
